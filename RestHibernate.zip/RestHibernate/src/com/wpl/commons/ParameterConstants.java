package com.wpl.commons;

public interface ParameterConstants {

	public static final String EMAIL = "email";

	//public static final String IS_LOGIN_THROUGH_FB = "fb";

	public static final String USERNAME = "uname";

	public static final String FIRST_NAME = "fname";

	public static final String LAST_NAME = "lname";

	public static final String PASSWORD = "password";


}
